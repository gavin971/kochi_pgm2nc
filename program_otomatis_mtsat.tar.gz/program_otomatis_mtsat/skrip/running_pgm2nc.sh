#!/bin/bash

`R CMD BATCH pgm2nc_regridcoarse_end1.R`
